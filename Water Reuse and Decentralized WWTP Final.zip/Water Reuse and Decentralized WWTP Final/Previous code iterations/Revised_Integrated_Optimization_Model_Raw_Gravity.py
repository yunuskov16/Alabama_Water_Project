# -*- coding: utf-8 -*-
"""
Created on Mon Jun 26 10:49:17 2023

@author: yunus
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 15:55:56 2023

@author: yunus
"""
from shapely import wkt

from shapely.ops import snap, split, nearest_points, substring
#from shapely.geometry import MultiPoint, LineString
from shapely.geometry import Polygon, box, Point, MultiPoint, LineString, MultiLineString, GeometryCollection
from osgeo import ogr
import igraph as ig
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import distance_matrix
from math import sin, cos, sqrt, atan2, radians
import sys
import geopandas as gpd
from shapely.geometry import Polygon, box, Point, LineString, MultiLineString
import xlwt
from xlwt import Workbook  
import os
from scipy.spatial import distance_matrix
import gurobipy as gp
from gurobipy import GRB
from scipy.spatial import distance_matrix
import networkx as nx
from sklearn.cluster import AgglomerativeClustering
import pyproj
from pyproj import Proj, transform
import osgeo as ogr
import pickle

#change path to integrated model

def get_buildings(name, state, xmini, xmaxi, ymini, ymaxi):
        #user inputs: State, city, and coordinates
    ymax = ymaxi
    xmin = xmini
    ymin = ymini
    xmax = xmaxi
    ######
    city_limits = Polygon([(xmin, ymin), (xmin, ymax), (xmax, ymax), (xmax, ymin)])
    
    filename = "https://usbuildingdata.blob.core.windows.net/usbuildings-v2/" + state +  ".geojson.zip"
    
    file = gpd.read_file(filename)
    clip_gdf = gpd.clip(file, city_limits)
    
    #get all these coordinates on a csv
    
    export_file_name = "Centralized_elevcluster_" + name + ".txt"
    counter = 0
    
    f = open(export_file_name, "w")
    f.write("buildings,V1,V2\n")
    for i in clip_gdf.geometry:
        counter += 1
        b_name = "B" + str(counter)
        f.write(b_name + "," + str(i.centroid.x) + "," + str(i.centroid.y) + "," + i.area + "\n")
    
    f.close()
    
    return export_file_name

def readGraphAndDF(city):
    df_name = city + '_df.csv'
    graph_name = city + 'road_node_graph.net'
    return_df = pd.read_csv(df_name)
    return_graph = nx.read_pajek(graph_name)
    
    return return_df, return_graph #first dataframe, second graph
    

def haversinedist(lat1, lon1, lat2, lon2):
    R = 6373.0
    
    lat1 = radians(lat1)
    lon1 = radians(lon1)
    lat2 = radians(lat2)
    lon2 = radians(lon2)
    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    
    distance = R * c
    return distance

def readBuildings(fileID):
    file = np.genfromtxt(fileID, delimiter = ",", skip_header = 1)
    return file[:,1:]

def readClusterFile(fileID):
    file = np.genfromtxt(fileID, delimiter=" ")
    if np.count_nonzero(file) <= 5:
        file_list = file
    else:
        file_list = file[:,1:]
    return file_list

def readClusterfileID(fileID):
    file_indexes = np.genfromtxt(fileID, delimiter=" ", dtype = str)
    if np.count_nonzero(file_indexes) <= 5:
        file_id = file_indexes[0]
    else:
        file_id = file_indexes[:,0]
    return file_id

def readArcs(fileID):
    file = np.genfromtxt(fileID, delimiter=" ", dtype = str)
    return file


#note: the slopes in this function take the from node as the start point(i) and the to node as the endpoint (j)
def findDistances(tree, dataframe):
    returnDictdist = {}
    for i, j in tree:
        lon1 = dataframe.loc[dataframe['n_id'] == i]['lon']
        lat1 = dataframe.loc[dataframe['n_id'] == i]['lat']
        lon2 = dataframe.loc[dataframe['n_id'] == j]['lon']
        lat2 = dataframe.loc[dataframe['n_id'] == j]['lat']
        distance = haversinedist(lat1, lon1, lat2, lon2)
        #meters divded meters
        returnDictdist[i,j] = distance * 1000
    
    return returnDictdist   

#this section of code makes sure the directed arcs drain into the source node
    
#this function takes a point and the list of arcs and the list of already accounted for arcs and finds
#all the arcs that are connected to a node, which have not already been insepcted in the repetition variable
#this section of code makes sure the directed arcs drain into the source node

#this function takes a point and the list of arcs and the list of already accounted for arcs and finds
#all the arcs that are connected to a node, which have not already been insepcted in the repetition variable
# def findconnectingnodes(source, arclist, repetition, arcs):
#     returnlist = list()
#     for i in range(len(arclist)):
#         for j in source:
#             if (arcs[i][0] == j or arcs[i][1] == j) and arclist[i] not in repetition and arclist[i][::-1] not in repetition:
#                 returnlist.append(arclist[i])
#     return returnlist


#this function goes through the directed mst and makes sure the directions go the right way
# def correctFlow(arcs1, outlet, arcs):
#     visitedToNodes = []
#     returnArcList = []
#     source_index = outlet
#     visitedToNodes.append(source_index)
#     tempNodes = [source_index]
#     #travels through all the arcs of the mst switches flow direction if it is facing the wrong way
#     while len(visitedToNodes) <= len(arcs):
#         tempToList = findconnectingnodes(tempNodes, arcs1, returnArcList)
#         for i in tempToList:
#             if i[0] in visitedToNodes:
#                 rev_tup = i[::-1]
#                 returnArcList.append(rev_tup)
#                 visitedToNodes.append(rev_tup[0])
#                 tempNodes.append(rev_tup[0])
#             else:
#                 returnArcList.append(i)
#                 visitedToNodes.append(i[0])
#                 tempNodes.append(i[0])
#         tempNodes = tempNodes[-len(tempToList):]
#         tempToList = []
        
#     return returnArcList
#flips the arcs if 
def flip(arcList, out):
    returnArcs = []
    returnStarts = []
    for i in arcList:
        if i[0] == out:
            returnArcs.append(i[::-1])
            returnStarts.append(i[1])
        elif i[1] == out:
            returnArcs.append(i)
            returnStarts.append(i[0])
    return returnArcs, returnStarts

def correctFlow2(arcsR, outletR):
    todealwith = arcsR
    row_count = 0
    visited = set()
    returnArcs = np.array([0,0])
    toVisit = [outletR]
    while len(visited) < len(todealwith):
        toVisit2 = []
        for i in toVisit:
            for j in range(len(todealwith)):
                if i == todealwith[j, 0] and tuple(todealwith[j]) not in visited:
                    returnArcs = np.vstack((returnArcs, todealwith[j][::-1]))
                    toVisit2.append(todealwith[j,1])
                    visited.add(tuple(todealwith[j]))
                    row_count += 1
                elif i == todealwith[j, 1] and tuple(todealwith[j]) not in visited:
                    returnArcs = np.vstack((returnArcs, todealwith[j]))
                    visited.add(tuple(todealwith[j]))
                    toVisit2.append(todealwith[j,0])
                    row_count += 1
        toVisit = toVisit2
    return returnArcs[1:,:]

def dw_layout(graph, nodes2, df, pipesize, arcDistances):
    #get layout
    nx.steiner_tree()
    
    m = gp.Model('Cluster1')
    
    #the following are the settings I use to make the code run faster, look at gurobi api to learn what these things all do
    #basically I have commented out everything that I found useful, but no longer need
    #you might have to fiddle around with the time limit if you are dealing with big clusters 100+, as the code will given a lot more constraints to solve
    m.Params.timeLimit = 1200
    

def gravity_Raw(arcFlow, arcs, nodes2, df, pipesize, outlet_node, arcDistances, inflow, bedding_cost_sq_ft, excavation, capital_cost_pump_station, pipecost, collection_om, ps_OM_cost, treat_om, fixed_treatment_cost, added_post_proc, hometreatment, Sheet, cluster, Pumps, pumpcounter, building_num):
    m = gp.Model('Cluster1')
    
    #the following are the settings I use to make the code run faster, look at gurobi api to learn what these things all do
    #basically I have commented out everything that I found useful, but no longer need
    #you might have to fiddle around with the time limit if you are dealing with big clusters 100+, as the code will given a lot more constraints to solve
    m.Params.timeLimit = 1200
    #always run feasibilitytol and intfeastotal together
    #m.Params.feasibilitytol = 0.01
    #m.Params.optimalitytol = 0.01
    #m.Params.IntFeasTol = 0.1
    #m.Params.tunecleanup = 1.0
    #m.Params.tunetimelimit = 3600
    #m.tune()
    #m.Params.Presolve = 0
    #m.Params.Method = 2
    #m.Params.PreQLinearize = 1
    #m.Params.Heuristics = 0.001
    


    #pipe diameter
    #in centimeters
    #pump location pumps are not used in this model and therefore not defined.
    pl = {}
    #pump capacity
    pc = {}
    
    pipeflow = arcFlow.copy()
    for i, j in arcFlow:
        pipeflow[i,j] = pipeflow[i,j] / 15850
        if (outlet_node, outlet_node + 'f') == (i,j):
            pl[i,j] = 1
            pc[i,j] = pipeflow[i,j]
        else:
            pl[i,j] = 0
            pc[i,j] = 0
            
    arc_sizes = m.addVars(pipeflow.keys(), pipesize, vtype = GRB.BINARY, name = "DIAMETER")

    #node elevation excavation in meters
    #upper bound is arbritrary maximum depth assuming 1 foot or 0.3048 meters of cover beneath the surface is needed for the pipes
    #a lower bound variable is created because future models might need to implement that depending on the site (digging too deep for excavation is not feasible for many projects)
    elevation_ub = dict()
    #elevation_lb = dict()
    for i in nodes2:
        elevation_ub[i] = float(df.loc[df['n_id'] == i]['elevation']) - 0.3048
        #elevation_lb[i] = threeDcluster[i[0], 2] - 5.3048
        
    #when installing pipes of different diameters we are going to use binary variables to indicate which one has been installed for what arc
    #each variable corresponds to a different pipe size (1 being the smallest and 11 being the largest)
    
    
    #piping cost is going to be a variable that adds up the cost for all the different pipes list previously
    
    #pipeflow is just arcflow but later you'll see we need to change it into m^3/s of water instead of gallons/min    
    
    #because we are using gravity flow for this model for all the arcs
    #the lift stations need to be fashioned in a way where the wastewater is being pushed up to a level where it can continue
    #using gravity low to drain to the next nodes after its been pushed up, to do this we created two elevations for each node
    #eIn is the elevation for a pipe comming into a node, eOut is the elevation of a pipe comming out of a node
    #eOut is always higher or the same height as eIn. If a pump station occurs before a given node the eOut elevation > eIn elevation    
    eIn = m.addVars(nodes2, lb = -GRB.INFINITY, ub = elevation_ub, name = 'In Node Elevation')
    eOut = m.addVars(nodes2, lb = -GRB.INFINITY, ub = elevation_ub, name = 'Out Node Elevation')
    
    #for this model we already know the treatment plant is at ground level and has been split up between a dummy node and actual treatment 
    #plant node (the final node) because this model only uses gravity flow though what we are going to do is assume the treatment plant node
    #is around a foot in the ground and the dummy variable node is at ground level, this allows water to flow using gravity from
    #the dummy node to the treatment plant node
    eOut[outlet_node] = float(df.loc[df['n_id'] == outlet_node]['elevation'])
    
    #this will track the difference between eIn and eOut for every node
    nodeElevDif = m.addVars(nodes2, lb = 0, name = 'Difference Between Node Elevations')
    
    
    #this basically ensures that there will be no lift station except for the dummy node because this model uses gravity flow only
    #(with the exception being for the treatment plant node at ground level)
    for i in nodes2:
        if i != outlet_node:
            nodeElevDif[i] = 0
    #this ensures that the treatment plant node does not experience any lift station either
    #nodeElevDif[(len(nodes)-1,)] = 0 # sets the elevation difference in the last two (treatment) links to 0. 
        
    #applying lower and upper bounds to slope (to increase the speed of this you can define lb and ub when slope is being initialized)
    #which would decrease runtime but I prefer this way so I can relax the slopes of different arcs and see how the result is affected

            
    #select one type of pipe for every arc/link
    m.addConstrs((gp.quicksum(arc_sizes[i,j,k] for k in pipesize) == 1 for i,j in pipeflow.keys()), "single size chosen")
    #in gurobi you cannot multiple three variables or set variables to powers so you have to create general constraints and auxiliary variables
    #to do that stuff for you
    for i,j in pipeflow.keys():
        if j == outlet_node:
            #m.addConstr((0.001 <= (-eIn[(i,)] + eIn[(j,)] - nodeElevDif[(i,)]) / arcDistances[i,j]), "slope min" + str([i,j]))
            #m.addConstr((0.1 >= (-eIn[(i,)] + eIn[(j,)] - nodeElevDif[(i,)]) / arcDistances[i,j]), "slope max" + str([i,j]))
            pass
        else:
            m.addConstr(
                    (0.01 <= (eIn[i] - eIn[j] + nodeElevDif[i]) / arcDistances[i,j]), "slope min" + str([i,j]))
            m.addConstr(
                    (0.1 >= (eIn[i] - eIn[j] + nodeElevDif[i]) / arcDistances[i,j]), "slope max" + str([i,j]))
    m.addConstrs((
        pipeflow[i,j] <= ((3.14/8)*gp.quicksum(arc_sizes[i,j,k]*k**2 for k in pipesize)) * 3 for i,j in pipeflow.keys()), "Velocity Max Constr")
    
    m.addConstrs((
        nodeElevDif[i] == eOut[i] - eIn[i] for i in nodes2), 'In_Node_Out_Node_Difference')
                
    #slope goes from i to j (from node to to node), this means a positive slope value means the pipe is going to a lower elevation
    #ensuring for gravity flow (note: this would not be the slope value in real life this only applies to this model)
    m.addConstrs((
        arcDistances[i,j]*(gp.quicksum(arc_sizes[i, j, k] / k**(16/3) for k in pipesize)) * (pipeflow[i,j] / (11.9879))**2 <= eIn[i] - eIn[j] + nodeElevDif[i] for i,j in pipeflow.keys()), "Manning Equation")
    

    #width of trench is at least 3 ft or approximately 1 meter plus diameter (see objective 1)
    #volume will be in cubic meters
    #cost is for excavation and bedding added together
    #for gravity you need pipe bedding (gravel underneath pipe so ground doesn't settle and pipe doesn't break)
    #4 in of bedding under gravity is incorporated into the beddding cost per square foot
    #$6 per square meter
    #bedding is first part excavation/infilling is second
    #cost accounts for 4 inches deep so just multiple by $6
    
    inindex, outindex = outlet_node, outlet_node + 'f'

    #excavation/infilling/bedding cost
    obj1 = gp.quicksum((1 + gp.quicksum(arc_sizes[i,j,k]*k for k in pipesize)*0.01) * arcDistances[i,j] * bedding_cost_sq_ft +\
                       excavation * (1 + gp.quicksum(arc_sizes[i,j,k]*k for k in pipesize)*0.01) * arcDistances[i,j] * 0.5 *\
                           ((elevation_ub[i] - eIn[i]) + (elevation_ub[j] - eOut[j])) for i, j in pipeflow.keys())
    #pump installation costs
    obj2 = gp.quicksum(pl[i,j] * capital_cost_pump_station for i,j in pipeflow.keys()) #+ pc[inindex,outindex] * ps_flow_cost
    #piping capital costs
    obj3 = gp.quicksum(arcDistances[i,j] * gp.quicksum(pipecost[str(k)] * arc_sizes[i, j, k] for k in pipesize) for i,j in pipeflow.keys()) 
    #pump operating costs yearly
    obj4 = collection_om * (building_num+1) + ps_OM_cost + treat_om #there is only one OM cost because only one pump station in this model
    obj = obj1 + obj2 + obj3 + obj4 + fixed_treatment_cost + ((arcFlow[inindex,outindex])) * added_post_proc * 60 * 24 + hometreatment * (building_num + 1)  #converts gals/min into gals per day
    #obj = obj1 + obj2 + obj3
    
    m.setObjective(obj, GRB.MINIMIZE)
    m.optimize()  
    #m.Params.Presolve = 0
    #m.Params.Method = 2
    #m.Params.PreQLinearize = 1
    #m.Params.Heuristics = 0.001
    
    m.setObjective(obj, GRB.MINIMIZE)
    #m.Params.tunetimelimit = 3600
    #m.tune()
    m.optimize()
    #presolver can be turned on in case the program takes too long to presolve and just needs to solve that solution
    #did not need it this time
    #p = m.presolve()
    #p.printStats()
    
    #writes down the cost values for each objective into the spreadsheet
    #note column six is meant to add any costs that do not need to be optimized into the total objective function cost
    #in this case the additional costs are 0, but in other models this column would be obj + additional costs
    Sheet.write(cluster, 1, obj1.getValue())
    Sheet.write(cluster, 2, obj2.getValue())
    Sheet.write(cluster, 3, obj3.getValue())
    Sheet.write(cluster, 4, obj4)
    Sheet.write(cluster, 5, m.objVal)
    
    
    #if the model is not working I uncomment this code to tell me what variables cannot be satisfied
    # print('The model is infeasible; computing IIS')
    # m.computeIIS()
    # if m.IISMinimal:
    #     print('IIS is minimal\n')
    # else:
    #     print('IIS is not minimal\n')
    # print('\nThe following constraint(s) cannot be satisfied:')
    # for c in m.getConstrs():
    #     if c.IISConstr:
    #         print('%s' % c.constrName)
    
    #once I find out what variables cannot be satisfied I can relax the constraints to figure out what aspects of the optimization 
    #we need to change. 
    #sometimes a variable is attached to several other variables, so relaxing the constraints can also help narrow down which variable
    #is actually causing probelms for the code
    # if m.status == GRB.INFEASIBLE:
    #     relaxvars = []
    #     relaxconstr = []
    #     for i in m.getVars():
    #         if 'velocity[' in str(i):
    #             relaxvars.append(i)
                    
    #     for j in m.getConstrs():
    #         if 'slope[' in str(j):
    #             relaxconstr.append(j)
                    
    #     lbpen = [3.0]*len(relaxvars)
    #     ubpen = [3.0]*len(relaxvars)
    #     rhspen = [1.0]*len(relaxconstr)
                    
    #     m.feasRelax(2, False, relaxvars, lbpen, ubpen, relaxconstr, rhspen)
    #     m.optimize()
    
    #saves all the model's variable names and their corresponding values as a txt file
    modelname = 'Decentralized_Uniontown_' + str(cluster) + "raw_grav" + ".csv"
    modelfile = open(modelname, "w")
    modelfile.write('Solution Value: %g \n' % m.objVal)
    for v in m.getVars():
        modelfile.write('%s %g \n' % (v.varName, v.x))
    modelfile.close()
    #m.close()
    
    #puts the excavated node elevations in a list for plotting
    #not the .x is to call the values of the gurobi values which some nodeElevDif vlaues are or are not depending on their index
#    final_elevations = []
#    for i in eIn:
#        if type(nodeElevDif[i]) == int:
#            value = eIn[i].x + nodeElevDif[i]
#        else:
#            value = eIn[i].x + nodeElevDif[i].x
#        final_elevations.append(value)    
    
    #background plot:
    #fig, ax = plt.subplots(1, figsize = (50, 50))
    
    #creating building points
    #cluster_dict = {}
    #source_dict = {}
    #cluster_dict["Building"] = nodes_notup#[:-1]
    #cluster_dict["Latitude"] = list(threeDcluster[:,1])#[:-1]
    #cluster_dict["Longitude"] = list(threeDcluster[:,0])#[:-1]
    #cluster_dict["Elevation"] = final_elevations#[:-1]
    
    #turning those points into data frames
    #cluster_df = pd.DataFrame(cluster_dict)
        
    cluster_df=pd.DataFrame(columns=["Buildings","Latitude","Longitude","Elevation"],\
                                    index=nodes2)

    for i in nodes2:
        value=0
        lat=0
        long=0
        if type(nodeElevDif[i]) == int:
            value=eIn[i].x + nodeElevDif[i]
        else:
            value=eIn[i].x + nodeElevDif[i].x
        lat=float(df.loc[df['n_id'] == i]['lat'])
        long=float(df.loc[df['n_id'] == i]['lon'])

        temp=[i,lat,long,value]
        cluster_df.loc[i]=temp
    
    
    
    clustergdf = gpd.GeoDataFrame(
        cluster_df, geometry=gpd.points_from_xy(cluster_df.Longitude, cluster_df.Latitude))
   
    #creating the pipelines
    #reads sf files from R code in the spatial features tab
    #has to replace lower case C with capital C
    clustermultilinelist = []
    for i,j in pipeflow.keys():
        i_lon = float(df.loc[df['n_id'] == i]['lon'])
        i_lat = float(df.loc[df['n_id'] == i]['lat'])
        j_lon = float(df.loc[df['n_id'] == j]['lon'])
        j_lat = float(df.loc[df['n_id'] == j]['lat'])
        frompointlon, frompointlat = i_lon, i_lat
        frompoint = Point(frompointlon, frompointlat)
        topointlon, topointlat = j_lon, j_lat
        topoint = Point(topointlon, topointlat)
        line = LineString([frompoint, topoint])
        clustermultilinelist.append(line)
    
    #does all the stuff to save the lines as a shapefile
    clustermultiline = MultiLineString(clustermultilinelist)
    # driver = ogr.GetDriverByName('Esri Shapefile')
    
    # pipelayoutfile = 'MST_Model_1_' + str(cluster) + '_pipelayout' + '.shp'
    # ds = driver.CreateDataSource(pipelayoutfile)
    # layer = ds.CreateLayer('', None, ogr.wkbMultiLineString)
    # # Add one attribute
    # layer.CreateField(ogr.FieldDefn('id', ogr.OFTInteger))
    # defn = layer.GetLayerDefn()
    
    # ## If there are multiple geometries, put the "for" loop here
    
    # # Create a new feature (attribute and geometry)
    # feat = ogr.Feature(defn)
    # feat.SetField('id', 123)
    
    # # Make a geometry, from Shapely object
    # geom = ogr.CreateGeometryFromWkb(clustermultiline.wkb)
    # feat.SetGeometry(geom)
    
    # layer.CreateFeature(feat)
    # feat = geom = None  # destroy these
    
    # # Save and close everything
    # ds = layer = feat = geom = None
    
    return pumpcounter

area = "Flagstaff"
#city = area
city = "Flagstaff2"
df, G = readGraphAndDF(area)
ngroup = 5

term_nodes = []

for i in range(len(df)):
    name = df.iloc[i]['n_id']
    if df.iloc[i]['n_demand'] > 0:
        term_nodes.append(name)
        add_node = name + 'self'
        G.add_edge(name, add_node, weight = 10)

G3 = G.to_undirected()
#####pick it up from here to figure out why we have edges with lengths longer than 101 m

test = [[float(df.loc[df['n_id'] == a]['x']), float(df.loc[df['n_id'] == a]['y'])] for a in term_nodes]
test1 = distance_matrix(test, test)

#dist_df = pd.DataFrame(test1, columns = list(complete_df['n_id']), index = list(complete_df['n_id']))

selected_data = test
#choose number of clusters with k
clustering_model = AgglomerativeClustering(n_clusters=ngroup, affinity='euclidean', linkage='ward')
a = clustering_model.fit(selected_data)
b = clustering_model.labels_

n_clust = []

for i in range(len(df)):
    row = df.iloc[i]
    name = row['n_id']
    if name not in term_nodes:
        n_clust.append(-1)
    else:
        clust_idx = term_nodes.index(name)
        clust = b[clust_idx]
        n_clust.append(clust)
        
term_nodes_dict = dict()
for i in range(0, ngroup):
    temp_node_list = []
    for j in range(len(term_nodes)):
        clust_num = b[j]
        if clust_num == i:
            temp_node_list.append(term_nodes[j])
    term_nodes_dict[i] = temp_node_list
    
mst_list = []
for i in range(0, ngroup):
    mst = nx.algorithms.approximation.steinertree.steiner_tree(G, term_nodes_dict[i], weight = 'weight')
    mst_list.append(mst)
        
lat = []
lon = []
inProj = Proj(init='epsg:2163')
outProj = Proj(init='epsg:4326')
for i in df['n_id']:
    row1 = df.loc[df['n_id'] == i]
    if len(row1) <= 1:
        row1 = df.loc[df['n_id'] == i]
        lon1, lat1 = transform(inProj, outProj, row1['x'], row1['y'])
        lat.append(float(lat1))
        lon.append(float(lon1))
    else:
        lon1, lat1 = float(row1['x']), float(row1['y'])
        lat.append(lat1)
        lon.append(lon1)
        
df['lat'] = lat
df['lon'] = lon

n_clust = []
for i in df['n_id']:
    for j in range(len(mst_list)):
        if i in mst_list[j].nodes:
            n_clust.append(j)
            break
        if j == len(mst_list)-1:
            n_clust.append(-1)
df['cluster'] = n_clust

#create dictionary for connected ab

#we are going to create a dictionary by connecting each building pair in one direction and then reverse the direction to save the computation time
#convert the points from strings into shapely objects
df['geometry'] = df['geometry'].apply(wkt.loads)
#gdf = gpd.GeoDataFrame(df, crs='epsg:4326')

build_road_dict = {}
counter=0

for i in range(ngroup):
    for j in range(len(term_nodes_dict[i])):
        Bj_name= term_nodes_dict[i][j]
        for k in range(j, len(term_nodes_dict[i])):
            counter+=1
            if j != k :
                Bk_name= term_nodes_dict[i][k]
                route = nx.shortest_path(G, Bj_name, Bk_name, weight='weight')
                temp_dist = 0
                temp_path = []
                for l in range(len(route)-1):
                    temp_dist += G.edges[route[l], route[l+1], 0]['weight']
                    temp_path.append((route[l], route[l+1]))
                build_road_dict[Bj_name, Bk_name] = [temp_dist, temp_path]
                #reverse path to include the same link but in a different direction
                #build_road_dict[building_list[j], building_list[i]] = [temp_dist, temp_path[::-1]]
            else:
                build_road_dict[Bj_name, Bj_name + 'self'] = [0, tuple(nx.shortest_path(G3, Bj_name, Bj_name+'self', weight = 'weight'))]
                #build_road_dict[Bi_name, Bi_name+'self'] = [0, tuple(nx.shortest_path(G3, i, i+'self', weight = 'length'))]
    
graph_dict = open("./" + area + "_all_building_road_paths_dict_seg.pkl", "wb")
pickle.dump(build_road_dict, graph_dict)
graph_dict.close()

#my graphs suck so I am fixing them
#for each house connected to a demand node 
building_txt = "Centralized_elevcluster_" + city + ".txt"

clusterfilename = building_txt
    
# load the files for building locations 
#clusterfile = os.path.realpath(os.path.join(os.path.dirname('Greenville_Case'), '.')) + '\\' + clusterfilename
building_coords0 = readBuildings(clusterfilename)
building_coords = building_coords0[:, :2]
# load the building coordinate file
building_coords = pd.read_csv(clusterfilename, index_col=0)
# convert to a shapefile to match nodes objective above - these will be merged into the graph
build_shp = gpd.GeoDataFrame(building_coords, 
            geometry=gpd.points_from_xy(building_coords.V1, building_coords.V2),
            crs="EPSG:4326")
build_shp["Area"] = building_coords0[:,2]
build_shp=build_shp.to_crs("EPSG:2163")
build_shp.insert(3,'n_id',None)
counter_N=1
for index, row in build_shp.iterrows():
    build_shp.loc[index,'n_id']= 'B'+str(counter_N)
    counter_N+=1


ww_dict = {}
dw_dict = {}
beta = 2 # gallons per square meter of housing (average between industrial of 20 gal/sqft and residential 0.5 gal/sqft)


for i in range(0, len(build_shp.geometry)):
    p = build_shp.geometry.iloc[i]
    pot_pts = nearest_points(build_shp.geometry.iloc[i], MultiPoint(list(df.geometry)))
    if len(pot_pts) == 1:
        node_row = df.loc[df['geometry'] == pot_pts[0]]
        if len(node_row) > 0:
            if list(node_row['n_id'])[0] not in ww_dict:
                ww_dict[list(node_row['n_id'])[0]] = 1
            else:
                ww_dict[list(node_row['n_id'])[0]] += 1
            #drinking water
            if list(node_row['n_id'])[0] not in dw_dict:
                dw_dict[list(node_row['n_id'])[0]] = build_shp.Area.iloc[i]
            else:
                dw_dict[list(node_row['n_id'])[0]] += build_shp.Area.iloc[i]
    else:
        node_row = df.loc[df['geometry'] == pot_pts[1]]        
        if list(node_row['n_id'])[0] not in ww_dict:
            ww_dict[list(node_row['n_id'])[0]] = 1
        else:
            ww_dict[list(node_row['n_id'])[0]] += 1
        #for drinking water
        if list(node_row['n_id'])[0] not in dw_dict:
            dw_dict[list(node_row['n_id'])[0]] = build_shp.Area.iloc[i]
        else:
            dw_dict[list(node_row['n_id'])[0]] += build_shp.Area.iloc[i]
#go through each row and add the dictionary id to the corresponding dataframe
#0 if there is no houses that are connected to a given road node
n_demand = []
dw_demand = []

for i in df['n_id']:
    if i not in ww_dict:
        n_demand.append(0)
        dw_demand.append(0)
    else:
        n_demand.append(ww_dict[i]/15850) #convert to m^3/s
        dw_demand.append(dw_dict[i]*beta/15850)
        
df['n_demand'] = n_demand
df['dw_demand'] = dw_demand

#everything above was a necessary part of the setup
#now that everything is set up we can do the optimization :)
dwDemTot_Dict = dict()
#set up total drinking water demand for a given cluster
for i in range(ngroup):
    dwDemTot_Dict[i] = sum(list(df.loc[df['cluster'] == i]['dw_demand'].values))


for a in range(ngroup):
    G_mst = mst_list[a]
    degree_dict = dict(G_mst.degree())
    graph_single_con_nodes = []
    graph_multi_con_nodes = []
    graph_single_con_edges = set()
    graph_multi_con_edges = set()

    for i in term_nodes_dict[a]:
        if degree_dict[i] <= 1:
            graph_single_con_nodes.append(i)
    
    graph_multi_con_nodes0 = set(graph_single_con_nodes).difference(set(G_mst.nodes))
    graph_multi_con_nodes = list(graph_multi_con_nodes0)
    half_edges = set()
    arc_Distances = dict()
    #do we need to have each edge in the graph mentioned twice?
    for i, j, k in G_mst.edges:
        arc_Distances[i, j] = G_mst.edges[i, j, k]['weight']
        arc_Distances[j, i] = arc_Distances[i, j]
        if i != j:
            if i in graph_single_con_nodes or j in graph_single_con_nodes:
                if i in graph_single_con_nodes: 
                    graph_single_con_edges.add((j, i))
                    graph_single_con_edges.add((i, j))
                    half_edges.add((i, j))
            else:
                graph_multi_con_edges.add((i, j))
                graph_multi_con_edges.add((j, i))
                half_edges.add((i, j))
    all_edges = list(graph_single_con_edges.union(graph_multi_con_edges))
    half_edges = list(half_edges)
    graph_single_con_edges = list(graph_single_con_edges)
    graph_multi_con_edges = list(graph_multi_con_edges)
            
    for b in G_mst.nodes:
        if b in term_nodes_dict[a]: 
            G_mst.nodes[b]['DWDem'] = float(df.loc[df['n_id'] == b]['dw_demand'])
        else:
            G_mst.nodes[b]['DWDem'] = 0
    
    #step 1: we are going to create an optimization model just for treatmentplant placement
    
    m = gp.Model('Cluster1')
    #pipe diameter
    
    m.Params.timeLimit = 1200
    m.Params.NonConvex = 2 
    #conversion number to m^3/sec 15850
    clust_build_road_dict = dict()

    for i, j in build_road_dict:
        if i in term_nodes_dict[a] and j in term_nodes_dict[a]:
            clust_build_road_dict[i, j] = build_road_dict[i, j]
            
    elevation_ub = dict()
    elevation_lb = dict()
    for i in G_mst.nodes:
                elevation_ub[i] = float(df.loc[df['n_id'] == i]['elevation']) - 0.3048
                elevation_lb[i] = float(df.loc[df['n_id'] == i]['elevation']) - 50 
   
    e = m.addVars(G_mst.nodes, lb = -GRB.INFINITY, ub = elevation_ub, name = 'In Node Elevation')
            
    pipesize = [0.05, 0.06, 0.08, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35,0.4,0.45,0.5,0.6,0.8,1.0, 5.0]
            
    connected = m.addVars(clust_build_road_dict, vtype = GRB.BINARY, name = "Connected")
    dwtp = m.addVars(G_mst.nodes, vtype = GRB.BINARY, name = "Drinking Plant Placement")
    wwtp = m.addVars(G_mst.nodes, vtype = GRB.BINARY, name = "Wastewater Plant Placement")
    tdhp = m.addVars(all_edges, name = "Head from pump")
    pl = m.addVars(all_edges, name = "Place Pump")
    hl = m.addVars(all_edges, name = "Head Loss")
    ph = m.addVars(G_mst.nodes, name = "Flow_nodes_prev")
    arc_sizes = m.addVars(all_edges, pipesize, vtype = GRB.BINARY, name = "DIAMETER")

    
    dwq = m.addVars(all_edges, name = "flow_links")
    NodeFlow = m.addVars(G_mst.nodes, name = "Flow_nodes_prev")
    #term nodes a is the drinking water demanded
    m.addConstrs((dwtp[j]*dwDemTot_Dict[a] <= dwq[j, i] for i, j in graph_single_con_edges), "Nodes on the ends of the graph dwtp flow")
    m.addConstrs(((1-dwtp[j])*(G_mst.nodes[j]['DWDem']) <= dwq[i, j] for i, j in graph_single_con_edges), "Nodes on end of graph building flow")
    m.addConstrs((dwtp[i]*dwDemTot_Dict[a] <= dwq[i, j] for i, j in graph_multi_con_nodes), "Nodes in Middle of Graph")
    m.addConstrs(((NodeFlow[i]-G_mst.nodes[i]['DWDem'])*(1-dwtp[i]) <= dwq[i, j] for i, j in graph_multi_con_nodes), "Nodes in Middle of Graph")

    m.addConstr((gp.quicksum(connected[r, s] for r, s in clust_build_road_dict) >= 1), name = "Connect WWTP to DWTP")
    m.addConstr(gp.quicksum(dwtp[i] for i in dwtp) >= 1)
    m.addConstr(gp.quicksum(wwtp[i] for i in wwtp) >= 1)
    m.addConstrs(dwq[i, j] + dwq[j, i] >= 1 for i, j in all_edges)
    
    m.addConstrs((
        gp.quicksum(arc_sizes[i, j, k] + arc_sizes[j, i , k] for k in pipesize) == 1 for i, j in half_edges), "Pick one size")
    
    m.addConstrs((
        dwq[i, j] <= gp.quicksum(3*arc_sizes[i, j, k]*(k**2)*0.25*3.14 for k in pipesize) for i, j in all_edges), "Max Velocity")
    
    
    #reverse i and j because the arcs were designed for the sewer direction
    m.addConstrs((
        ph[i] == ph[j] - hl[i, j] + e[j] - e[i] + tdhp[i, j] for i, j in all_edges), "Energy Balance")
    
    m.addConstrs((
        tdhp[i, j] - tdhp[j, i] == 0 for i, j in half_edges), "Ensures head imparted stays same")
    
    
    #C value comes from roughness coefficient number
    C = 140
    
    arc_sizes_exp = m.addVars(arc_sizes.keys(), name = "Arcsizes Exponential")
    dwq_exp = m.addVars(dwq.keys(), name = "Flow Exponential")
    for i, j in all_edges:
        m.addGenConstrPow(dwq_exp[i, j], dwq[i, j], 1.852)
        for k in pipesize:
            m.addGenConstrPow(arc_sizes_exp[i,j,k], arc_sizes[i,j,k], -4.87)
        
    m.addConstrs((
        hl[i, j] == gp.quicksum(arc_sizes_exp[i, j, k]*k for k in pipesize)*10700*arc_Distances[i, j]*1*(dwq_exp[i,j])/C for i, j in all_edges), "Headloss")
    
    m.addConstrs((
        tdhp[i, j] <= pl[i,j]*1000000 for i, j in all_edges), "Total Dynamic Head")
    wwtp_capex = 1000000
    dwtp_capex = 1000000
    
    pipecost = {'0.05': 18, '0.06': 19, '0.08': 22, \
                '0.1': 25, '0.15': 62,'0.2': 171,\
                '0.25': 187, '0.3': 203, '0.35':230, \
                '0.4': 246, '0.45':262, '0.5':300, '0.6': 350,\
                '0.8': 500, '1.0': 550, '5.0': 5000}
            # pipe costs without excavation
    
    obj1 = gp.quicksum(gp.quicksum(arc_sizes[i, j, k]*pipecost[str(k)] for k in pipesize)*arc_Distances[i, j] for i, j in all_edges)
    PC = 490 #cost of a pump station
    obj2 = gp.quicksum(pl[i,j]*PC for i, j in all_edges)
    
    COL_OM = 1000 #OM for pipes
    PS_OM = 49#OM for pumps
    Num_Connected = len(G_mst.nodes)
    EX_Cost = 25
    
    obj3 = COL_OM*Num_Connected + gp.quicksum(pl[i,j]*PS_OM for i, j in all_edges)
    obj4 = gp.quicksum(EX_Cost*arc_Distances[i, j]*((elevation_ub[i]-e[i]+0.3048)+(elevation_ub[j]-e[j]+0.3048))*0.5 for i,j in all_edges)
    obj = obj1 + obj2 + obj3 + obj4
    
    
    m.setObjective(obj, GRB.MINIMIZE)
    #m.Params.tunetimelimit = 3600
    #m.tune()
    m.optimize()
    
    # print('The model is infeasible; computing IIS')
    # m.computeIIS()
    # if m.IISMinimal:
    #     print('IIS is minimal\n')
    # else:
    #     print('IIS is not minimal\n')
    # print('\nThe following constraint(s) cannot be satisfied:')
    # for c in m.getConstrs():
    #     if c.IISConstr:
    #         print('%s' % c.constrName)
    
    #check to make sure graph is connected
    checkG = nx.Graph()
    for i, j in dwq:
        if dwq[i, j].x == 1:
            checkG.add_edge(i, j)
    
    wwtp_chosen = []
    dwtp_chosen = []
    for i in wwtp:
        if wwtp[i].x == 1:
            wwtp_chosen.append(i)
        if dwtp[i].x == 1:
            dwtp_chosen.append(i)
    try:
        len(wwtp_chosen) == 1 or len(dwtp_chosen) == 1
    except:
        print('More than one was chosen')
        break
        
    try:
        nx.is_connected(checkG) == True
    except:
        print("Pipes are not a connected network")
        break
    
#first we need to get drinking water and wastewater demands of every building


#first we need to make sure the flow stuff works so lets just do a flow optimization with
#a simple constraint that will selelct the dwtp node
