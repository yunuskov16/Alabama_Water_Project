# -*- coding: utf-8 -*-
"""
Created on Mon Jun 26 10:49:17 2023

@author: yunus
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 15:55:56 2023

@author: yunus
"""
from shapely import wkt

from shapely.ops import snap, split, nearest_points, substring
#from shapely.geometry import MultiPoint, LineString
from shapely.geometry import Polygon, box, Point, MultiPoint, LineString, MultiLineString, GeometryCollection
from osgeo import ogr
import igraph as ig
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import distance_matrix
from math import sin, cos, sqrt, atan2, radians
import sys
import geopandas as gpd
from shapely.geometry import Polygon, box, Point, LineString, MultiLineString
import xlwt
from xlwt import Workbook  
import os
from scipy.spatial import distance_matrix
import gurobipy as gp
from gurobipy import GRB
from scipy.spatial import distance_matrix
import networkx as nx
from sklearn.cluster import AgglomerativeClustering
import pyproj
from pyproj import Proj, transform
import osgeo as ogr
import pickle

#change path to integrated model

def get_buildings(name, state, xmini, xmaxi, ymini, ymaxi):
        #user inputs: State, city, and coordinates
    ymax = ymaxi
    xmin = xmini
    ymin = ymini
    xmax = xmaxi
    ######
    city_limits = Polygon([(xmin, ymin), (xmin, ymax), (xmax, ymax), (xmax, ymin)])
    
    filename = "https://usbuildingdata.blob.core.windows.net/usbuildings-v2/" + state +  ".geojson.zip"
    
    file = gpd.read_file(filename)
    clip_gdf = gpd.clip(file, city_limits)
    
    #get all these coordinates on a csv
    
    export_file_name = "Centralized_elevcluster_" + name + ".txt"
    counter = 0
    
    f = open(export_file_name, "w")
    f.write("buildings,V1,V2\n")
    for i in clip_gdf.geometry:
        counter += 1
        b_name = "B" + str(counter)
        f.write(b_name + "," + str(i.centroid.x) + "," + str(i.centroid.y) + "," + i.area + "\n")
    
    f.close()
    
    return export_file_name

def readGraphAndDF(city):
    df_name = city + '_df.csv'
    graph_name = city + 'road_node_graph.net'
    return_df = pd.read_csv(df_name)
    return_graph = nx.read_pajek(graph_name)
    
    return return_df, return_graph #first dataframe, second graph
    

def haversinedist(lat1, lon1, lat2, lon2):
    R = 6373.0
    
    lat1 = radians(lat1)
    lon1 = radians(lon1)
    lat2 = radians(lat2)
    lon2 = radians(lon2)
    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    
    distance = R * c
    return distance

def readBuildings(fileID):
    file = np.genfromtxt(fileID, delimiter = ",", skip_header = 1)
    return file[:,1:]

def readClusterFile(fileID):
    file = np.genfromtxt(fileID, delimiter=" ")
    if np.count_nonzero(file) <= 5:
        file_list = file
    else:
        file_list = file[:,1:]
    return file_list

def readClusterfileID(fileID):
    file_indexes = np.genfromtxt(fileID, delimiter=" ", dtype = str)
    if np.count_nonzero(file_indexes) <= 5:
        file_id = file_indexes[0]
    else:
        file_id = file_indexes[:,0]
    return file_id

def readArcs(fileID):
    file = np.genfromtxt(fileID, delimiter=" ", dtype = str)
    return file


#note: the slopes in this function take the from node as the start point(i) and the to node as the endpoint (j)
def findDistances(tree, dataframe):
    returnDictdist = {}
    for i, j in tree:
        lon1 = dataframe.loc[dataframe['n_id'] == i]['lon']
        lat1 = dataframe.loc[dataframe['n_id'] == i]['lat']
        lon2 = dataframe.loc[dataframe['n_id'] == j]['lon']
        lat2 = dataframe.loc[dataframe['n_id'] == j]['lat']
        distance = haversinedist(lat1, lon1, lat2, lon2)
        #meters divded meters
        returnDictdist[i,j] = distance * 1000
    
    return returnDictdist   


def flip(arcList, out):
    returnArcs = []
    returnStarts = []
    for i in arcList:
        if i[0] == out:
            returnArcs.append(i[::-1])
            returnStarts.append(i[1])
        elif i[1] == out:
            returnArcs.append(i)
            returnStarts.append(i[0])
    return returnArcs, returnStarts

def correctFlow2(arcsR, outletR):
    todealwith = arcsR
    row_count = 0
    visited = set()
    returnArcs = np.array([0,0])
    toVisit = [outletR]
    while len(visited) < len(todealwith):
        toVisit2 = []
        for i in toVisit:
            for j in range(len(todealwith)):
                if i == todealwith[j, 0] and tuple(todealwith[j]) not in visited:
                    returnArcs = np.vstack((returnArcs, todealwith[j][::-1]))
                    toVisit2.append(todealwith[j,1])
                    visited.add(tuple(todealwith[j]))
                    row_count += 1
                elif i == todealwith[j, 1] and tuple(todealwith[j]) not in visited:
                    returnArcs = np.vstack((returnArcs, todealwith[j]))
                    visited.add(tuple(todealwith[j]))
                    toVisit2.append(todealwith[j,0])
                    row_count += 1
        toVisit = toVisit2
    return returnArcs[1:,:]

#for the case study for flagstaff AZ:
# area = "Flagstaff"
# #city = area
# city = "Flagstaff2"
# df, G = readGraphAndDF(area)
# ngroup = 5

# term_nodes = []

# for i in range(len(df)):
#     name = df.iloc[i]['n_id']
#     if df.iloc[i]['n_demand'] > 0:
#         term_nodes.append(name)
#         add_node = name + 'self'
#         G.add_edge(name, add_node, weight = 10)

# G3 = G.to_undirected()
# #####pick it up from here to figure out why we have edges with lengths longer than 101 m

# test = [[float(df.loc[df['n_id'] == a]['x']), float(df.loc[df['n_id'] == a]['y'])] for a in term_nodes]
# test1 = distance_matrix(test, test)

# #dist_df = pd.DataFrame(test1, columns = list(complete_df['n_id']), index = list(complete_df['n_id']))

# selected_data = test
# #choose number of clusters with k
# clustering_model = AgglomerativeClustering(n_clusters=ngroup, affinity='euclidean', linkage='ward')
# a = clustering_model.fit(selected_data)
# b = clustering_model.labels_

# n_clust = []

# for i in range(len(df)):
#     row = df.iloc[i]
#     name = row['n_id']
#     if name not in term_nodes:
#         n_clust.append(-1)
#     else:
#         clust_idx = term_nodes.index(name)
#         clust = b[clust_idx]
#         n_clust.append(clust)
        
# term_nodes_dict = dict()
# for i in range(0, ngroup):
#     temp_node_list = []
#     for j in range(len(term_nodes)):
#         clust_num = b[j]
#         if clust_num == i:
#             temp_node_list.append(term_nodes[j])
#     term_nodes_dict[i] = temp_node_list
    
# mst_list = []
# for i in range(0, ngroup):
#     mst = nx.algorithms.approximation.steinertree.steiner_tree(G, term_nodes_dict[i], weight = 'weight')
#     mst_list.append(mst)
        
# lat = []
# lon = []
# inProj = Proj(init='epsg:2163')
# outProj = Proj(init='epsg:4326')
# for i in df['n_id']:
#     row1 = df.loc[df['n_id'] == i]
#     if len(row1) <= 1:
#         row1 = df.loc[df['n_id'] == i]
#         lon1, lat1 = transform(inProj, outProj, row1['x'], row1['y'])
#         lat.append(float(lat1))
#         lon.append(float(lon1))
#     else:
#         lon1, lat1 = float(row1['x']), float(row1['y'])
#         lat.append(lat1)
#         lon.append(lon1)
        
# df['lat'] = lat
# df['lon'] = lon

# n_clust = []
# for i in df['n_id']:
#     for j in range(len(mst_list)):
#         if i in mst_list[j].nodes:
#             n_clust.append(j)
#             break
#         if j == len(mst_list)-1:
#             n_clust.append(-1)
# df['cluster'] = n_clust

# #create dictionary for connected ab

# #we are going to create a dictionary by connecting each building pair in one direction and then reverse the direction to save the computation time
# #convert the points from strings into shapely objects
# df['geometry'] = df['geometry'].apply(wkt.loads)
# #gdf = gpd.GeoDataFrame(df, crs='epsg:4326')

# build_road_dict = {}
# counter=0

# for i in range(ngroup):
#     for j in range(len(term_nodes_dict[i])):
#         Bj_name= term_nodes_dict[i][j]
#         for k in range(j, len(term_nodes_dict[i])):
#             counter+=1
#             if j != k :
#                 Bk_name= term_nodes_dict[i][k]
#                 route = nx.shortest_path(G, Bj_name, Bk_name, weight='weight')
#                 temp_dist = 0
#                 temp_path = []
#                 for l in range(len(route)-1):
#                     temp_dist += G.edges[route[l], route[l+1], 0]['weight']
#                     temp_path.append((route[l], route[l+1]))
#                 build_road_dict[Bj_name, Bk_name] = [temp_dist, temp_path]
#                 #reverse path to include the same link but in a different direction
#                 #build_road_dict[building_list[j], building_list[i]] = [temp_dist, temp_path[::-1]]
#             else:
#                 build_road_dict[Bj_name, Bj_name + 'self'] = [0, tuple(nx.shortest_path(G3, Bj_name, Bj_name+'self', weight = 'weight'))]
#                 #build_road_dict[Bi_name, Bi_name+'self'] = [0, tuple(nx.shortest_path(G3, i, i+'self', weight = 'length'))]
    
# graph_dict = open("./" + area + "_all_building_road_paths_dict_seg.pkl", "wb")
# pickle.dump(build_road_dict, graph_dict)
# graph_dict.close()

# #my graphs suck so I am fixing them
# #for each house connected to a demand node 
# building_txt = "Centralized_elevcluster_" + city + ".txt"

# clusterfilename = building_txt
    
# # load the files for building locations 
# #clusterfile = os.path.realpath(os.path.join(os.path.dirname('Greenville_Case'), '.')) + '\\' + clusterfilename
# building_coords0 = readBuildings(clusterfilename)
# building_coords = building_coords0[:, :2]
# # load the building coordinate file
# building_coords = pd.read_csv(clusterfilename, index_col=0)
# # convert to a shapefile to match nodes objective above - these will be merged into the graph
# build_shp = gpd.GeoDataFrame(building_coords, 
#             geometry=gpd.points_from_xy(building_coords.V1, building_coords.V2),
#             crs="EPSG:4326")
# build_shp["Area"] = building_coords0[:,2]
# build_shp=build_shp.to_crs("EPSG:2163")
# build_shp.insert(3,'n_id',None)
# counter_N=1
# for index, row in build_shp.iterrows():
#     build_shp.loc[index,'n_id']= 'B'+str(counter_N)
#     counter_N+=1


# ww_dict = {}
# dw_dict = {}
# beta = 2 # gallons per square meter of housing (average between industrial of 20 gal/sqft and residential 0.5 gal/sqft)


# for i in range(0, len(build_shp.geometry)):
#     p = build_shp.geometry.iloc[i]
#     pot_pts = nearest_points(build_shp.geometry.iloc[i], MultiPoint(list(df.geometry)))
#     if len(pot_pts) == 1:
#         node_row = df.loc[df['geometry'] == pot_pts[0]]
#         if len(node_row) > 0:
#             if list(node_row['n_id'])[0] not in ww_dict:
#                 ww_dict[list(node_row['n_id'])[0]] = 1
#             else:
#                 ww_dict[list(node_row['n_id'])[0]] += 1
#             #drinking water
#             if list(node_row['n_id'])[0] not in dw_dict:
#                 dw_dict[list(node_row['n_id'])[0]] = build_shp.Area.iloc[i]
#             else:
#                 dw_dict[list(node_row['n_id'])[0]] += build_shp.Area.iloc[i]
#     else:
#         node_row = df.loc[df['geometry'] == pot_pts[1]]        
#         if list(node_row['n_id'])[0] not in ww_dict:
#             ww_dict[list(node_row['n_id'])[0]] = 1
#         else:
#             ww_dict[list(node_row['n_id'])[0]] += 1
#         #for drinking water
#         if list(node_row['n_id'])[0] not in dw_dict:
#             dw_dict[list(node_row['n_id'])[0]] = build_shp.Area.iloc[i]
#         else:
#             dw_dict[list(node_row['n_id'])[0]] += build_shp.Area.iloc[i]
# #go through each row and add the dictionary id to the corresponding dataframe
# #0 if there is no houses that are connected to a given road node
# n_demand = []
# dw_demand = []

# for i in df['n_id']:
#     if i not in ww_dict:
#         n_demand.append(0)
#         dw_demand.append(0)
#     else:
#         n_demand.append(ww_dict[i]/15850) #convert to m^3/s
#         dw_demand.append(dw_dict[i]*beta/15850)
        
# df['n_demand'] = n_demand
# df['dw_demand'] = dw_demand

# #everything above was a necessary part of the setup
# #now that everything is set up we can do the optimization :)
# dwDemTot_Dict = dict()
# #set up total drinking water demand for a given cluster
# for i in range(ngroup):
#     dwDemTot_Dict[i] = sum(list(df.loc[df['cluster'] == i]['dw_demand'].values))


#for a in range(ngroup):
    # G_mst = mst_list[a]
    # degree_dict = dict(G_mst.degree())
    # graph_single_con_nodes = []
    # graph_multi_con_nodes = []
    # graph_single_con_edges = set()
    # graph_multi_con_edges = set()

    # for i in term_nodes_dict[a]:
    #     if degree_dict[i] <= 1:
    #         graph_single_con_nodes.append(i)
    
    # graph_multi_con_nodes0 = set(graph_single_con_nodes).difference(set(G_mst.nodes))
    # graph_multi_con_nodes = list(graph_multi_con_nodes0)
    # half_edges = set()
    # all_edges = set()
    # arc_Distances = dict()
    # #do we need to have each edge in the graph mentioned twice?
    # for i, j, k in G_mst.edges:
    #     arc_Distances[i, j] = G_mst.edges[i, j, k]['weight']
    #     arc_Distances[j, i] = arc_Distances[i, j]
    #     if i != j:
    #         if i in graph_single_con_nodes or j in graph_single_con_nodes:
    #             if i in graph_single_con_nodes: 
    #                 graph_single_con_edges.add((i, j))
    #                 half_edges.add((i, j))
    #             if j in graph_single_con_nodes:
    #                 graph_single_con_edges.add((j, i))
    #                 half_edges.add((j, i))
    #             all_edges.add((i, j))
    #             all_edges.add((j, i))
    #         else:
    #             graph_multi_con_edges.add((i, j))
    #             graph_multi_con_edges.add((j, i))
    #             half_edges.add((i, j))
    #             all_edges.add((i, j))
    #             all_edges.add((j, i))
    # all_edges = list(all_edges)
    # half_edges = list(half_edges)
    # graph_single_con_edges = list(graph_single_con_edges)
    # graph_multi_con_edges = list(graph_multi_con_edges)
            
    # for b in G_mst.nodes:
    #     if b in term_nodes_dict[a]: 
    #         G_mst.nodes[b]['DWDem'] = float(df.loc[df['n_id'] == b]['dw_demand'])
    #     else:
    #         G_mst.nodes[b]['DWDem'] = 0
    
#step 1: we are going to create an optimization model just for treatmentplant placement
x_coords = [0, 0, 100, 100, 100, 100, 200, 200, 200, 200]
y_coords = [100, 200, 0, 100, 200, 400, 100, 200, 400, 500]
elev = [50, 50, 55, 60, 65, 60, 60, 55, 60, 55]
G_mst = nx.Graph()
for i in range(10):
    name = "R" + str(i+1)
    G_mst.add_node(name)
    G_mst.nodes[name]['x'] = x_coords[i]
    G_mst.nodes[name]['y'] = y_coords[i]
    G_mst.nodes[name]["WWDem"] = 1#250/(60*24)
    G_mst.nodes[name]["DWDem"] = 1*0.1*(1+i) #assigns some random water demand to each node
    G_mst.nodes[name]['elevation'] = elev[i]
#create arbritrary network
G_mst.add_edge("R1", "R4")
G_mst.add_edge("R3", "R4")
G_mst.add_edge("R7", "R4")
G_mst.add_edge("R5", "R4")
G_mst.add_edge("R2", "R5")
G_mst.add_edge("R5", "R8")
G_mst.add_edge("R6", "R5")
G_mst.add_edge("R6", "R9")
G_mst.add_edge("R9", "R10")

G_mst = nx.to_undirected(G_mst)
arc_Distances = dict()
for i, j in G_mst.edges:
    p1 = Point(G_mst.nodes[i]['x'], G_mst.nodes[i]['y'])
    p2 = Point(G_mst.nodes[j]['x'], G_mst.nodes[j]['y'])
    G_mst.edges[i,j]['weight'] = p1.distance(p2)
    arc_Distances[i, j] = p1.distance(p2)
    arc_Distances[j, i] = arc_Distances[i,j]


m = gp.Model('Cluster1')
#pipe diameter



#conversion number to m^3/sec 15850
clust_build_road_dict = dict()
graph_single_con_nodes = set()
graph_multi_con_nodes = set()
graph_single_con_edges = set()
graph_multi_con_edges = set()

for i in dict(G_mst.degree()):
    if dict(G_mst.degree())[i] == 1:
        graph_single_con_nodes.add(i)
    else:
        graph_multi_con_nodes.add(i)

for i,j in G_mst.edges:
    if i in graph_single_con_nodes: 
        graph_single_con_edges.add((i, j))
    elif j in graph_single_con_nodes:
        graph_single_con_edges.add((j, i))
    else:
        graph_multi_con_edges.add((i, j))
        graph_multi_con_edges.add((j, i))

elevation_ub = dict()
elevation_lb = dict()
for i in G_mst.nodes:
    elevation_ub[i] = G_mst.nodes[i]['elevation'] 
    elevation_lb[i] = G_mst.nodes[i]['elevation'] - 30
    for j in G_mst.nodes:
        if i != j:
            route = nx.shortest_path(G_mst, i, j, weight='weight')
            dist = nx.shortest_path_length(G_mst, i, j, weight='weight')
            clust_build_road_dict[i, j] = [dist, route]
        
        
all_edges = list(G_mst.edges) + [i[::-1] for i in list(G_mst.edges)]
half_edges = list(G_mst.edges)
total_water_dem = sum([G_mst.nodes[i]['DWDem'] for i in G_mst.nodes])
total_waste_dem = sum([G_mst.nodes[i]['WWDem'] for i in G_mst.nodes])
m.Params.timeLimit = 120
m.Params.NonConvex = 2
pipesize = [0.05, 0.06, 0.08, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35,0.4,0.45, 0.50, 0.60, 0.80, 1.0, 1.5, 2.0, 5.0]
e = m.addVars(G_mst.nodes, lb = elevation_lb, ub = elevation_ub, name = 'In Node Elevation')
    
re = m.addVar(name = "Water Reused")
gw = m.addVar(name = "Ground Water Extracted")
sw = m.addVar(name = "Surface Water Extracted")
            
                  
connected = m.addVars(clust_build_road_dict, vtype = GRB.BINARY, name = "Connected")
dwtp = m.addVars(G_mst.nodes, vtype = GRB.BINARY, name = "Drinking Plant Placement")
wwtp = m.addVars(G_mst.nodes, vtype = GRB.BINARY, name = "Wastewater Plant Placement")
tdhp = m.addVars(all_edges, name = "Head from pump")
tdhp_bin = m.addVars(all_edges, vtype = GRB.BINARY, name = "Head direction")
pl = m.addVars(all_edges, name = "Place Pump")
hl = m.addVars(all_edges, name = "Head Loss")
ph = m.addVars(G_mst.nodes, name = "Flow_nodes_prev", lb = 7, ub = 56)
dw_arc_sizes = m.addVars(all_edges, pipesize, vtype = GRB.BINARY, name = "DW DIAMETER")
ww_arc_sizes = m.addVars(all_edges, pipesize, vtype = GRB.BINARY, name = "WW Diameter")



dwq = m.addVars(all_edges, name = "dw_flow_links")
wwq = m.addVars(all_edges, name = "ww_flow_links")
#dwq_bin = m.addVars(all_edges, vtype = GRB.BINARY, name = "Direction")
#NodeFlow = m.addVars(G_mst.nodes, name = "Flow_nodes_prev")
#term nodes a is the drinking water demanded
#m.addConstrs((dwtp[j]*dwDemTot_Dict[a] <= dwq[j, i]*dwq_bin[] for i, j in half_edges), "Nodes on the ends of the graph dwtp flow")
# m.addConstrs(((1-dwtp[i])*(sum([G_mst.nodes[i]['DWDem'] for i in G_mst.nodes])) <= dwq[j, i]*dwq_bin[j, i] for i, j in graph_single_con_edges), "Nodes on end of graph building flow")
# #m.addConstrs((dwtp[i]*dwDemTot_Dict[a] == dwq[i, j]*dwq_bin[i,j] for i, j in graph_single_con_edges), "Treatment Plant Flow Edges")
# m.addConstrs((dwtp[i]*(sum([G_mst.nodes[i]['DWDem'] for i in G_mst.nodes])-G_mst.nodes[i]['DWDem']) <= dwq.sum('*', i) for i in G_mst.nodes), "Nodes in Middle of Graph")
# m.addConstrs((dwtp[i] <= dwq_bin[j, i] for i, j in all_edges), "Ensuring direction is chosen")

# m.addConstrs((
#     (1-dwtp[i])*(dwq.sum('*', i) + (G_mst.nodes[i]['DWDem'])) <= dwq[i, j]*dwq_bin[i,j] for i, j in graph_multi_con_edges), "Idk")
#m.addConstrs(((dwq.sum('*', i) - G_mst.nodes[i]['DWDem'])*(1-dwtp[i]) + dwtp[i]*dwDemTot_Dict[a] <= dwq.sum(i, '*') for i in G_mst.nodes), "Nodes in Middle of Graph")

m.addConstr((gp.quicksum(wwtp[r]*dwtp[s] for r, s in clust_build_road_dict) >= 1), name = "Connect WWTP to DWTP")
m.addConstr((gp.quicksum(wwtp[r]*dwtp[s] for r, s in clust_build_road_dict) <= gp.quicksum(connected[r,s] for r, s in clust_build_road_dict)), name = "Connect WWTP to DWTP")
m.addConstr(gp.quicksum(dwtp[i] for i in dwtp) == 1)
m.addConstr(gp.quicksum(wwtp[i] for i in wwtp) == 1)


#only covers flow demand for edge cases
m.addConstrs((
    G_mst.nodes[i]['DWDem']*(1-dwtp[i]) <= dwq.sum('*', i) for i in graph_single_con_nodes), "Flow Balance")
#ensures that flow does not go the wrong way for edge cases
m.addConstrs((
    dwq.sum(i, '*')*(1-dwtp[i]) <= 0 for i in graph_single_con_nodes), "Ensures no flow goes back into the graph from demand nodes")

#covers both edge and center cases pretty well
m.addConstrs((
    dwtp[i]*(total_water_dem-G_mst.nodes[i]['DWDem']) <= dwq.sum(i, '*') for i in G_mst.nodes), "Flow Balance Treatment Plant")
#now we need to deal with the center water demand
#so we have the treatment plant vibes covered with the constraint above
#The issue is we need to allocate the right amount of flow to each path
m.addConstrs((
    dwq.sum('*', i) >= (dwq.sum(i, '*') + G_mst.nodes[i]['DWDem'])*(1-dwtp[i]) for i in graph_multi_con_nodes), "Flow Continuity")

#only covers flow demand for edge cases
m.addConstrs((
    G_mst.nodes[i]['WWDem']*(1-wwtp[i]) <= wwq.sum('*', i) for i in graph_single_con_nodes), "Flow Balance")
#ensures that flow does not go the wrong way for edge cases
m.addConstrs((
    wwq.sum(i, '*')*(1-wwtp[i]) <= 0 for i in graph_single_con_nodes), "Ensures no flow goes back into the graph from demand nodes")

#covers both edge and center cases pretty well
m.addConstrs((
    wwtp[i]*(total_waste_dem-G_mst.nodes[i]['WWDem']) <= wwq.sum(i, '*') for i in G_mst.nodes), "Flow Balance Treatment Plant")
#now we need to deal with the center water demand
#so we have the treatment plant vibes covered with the constraint above
#The issue is we need to allocate the right amount of flow to each path
m.addConstrs((
    wwq.sum('*', i) >= (wwq.sum(i, '*') + G_mst.nodes[i]['WWDem'])*(1-wwtp[i]) for i in graph_multi_con_nodes), "Flow Continuity")


for i in G_mst.nodes:
    m.addConstr((
        e[i] <= dwtp[i]*G_mst.nodes[i]['elevation'] + (1-dwtp[i])*(G_mst.nodes[i]['elevation']-0.308)), "Treatment Plant Final Elevation")

#m.addConstr(gp.quicksum(dwtp[i]*dwq_bin.sum(i, '*') for i in dwtp) >= 1)
#m.addConstr(gp.quicksum(wwtp[i] for i in wwtp) == 1)
# m.addConstrs((
#     dwq_bin[i, j] + dwq_bin[j, i] >= 1 for i, j in half_edges), "Flow Direction")
# for i,j in all_edges:
#     m.addConstr((dwq_bin[i,j] == 1) >> (dwq[i, j] >= G_mst.nodes[i]['DWDem']))
#     m.addConstr((dwq_bin[i,j] == 0) >> (dwq[i, j] <= 0))
m.addConstrs((
        gp.quicksum(dw_arc_sizes[i, j, k] for k in pipesize) <= 1 for i, j in all_edges), "Pick one size")

#m.addConstrs((
#    tdhp_bin[i, j] + tdhp_bin[j, i] == 1 for i, j in half_edges), "Pumps")

#m.addConstrs((
#        gp.quicksum(dw_arc_sizes[i, j, k] + dw_arc_sizes[j, i , k] for k in pipesize) <= 1.1 for i, j in half_edges), "Pick one size")
    
m.addConstrs((
    dwq[i,j] <= gp.quicksum(3*dw_arc_sizes[i, j, k]*(k**2)*0.25*3.14 for k in pipesize) for i,j in all_edges) , "Max Velocity")

    
#reverse i and j because the arcs were designed for the sewer direction
m.addConstrs((
    ph[i] == ph[j] - hl[i, j] + e[j] - e[i] + tdhp[i, j]*tdhp_bin[i,j] for i, j in all_edges), "Energy Balance")

#m.addConstrs((
#    tdhp[i, j] - tdhp[j, i] == 0 for i, j in half_edges), "Ensures head imparted stays same")


#C value comes from roughness coefficient number
C = 140

dwq_exp = m.addVars(dwq.keys(), name = "Flow Exponential")
for i, j in all_edges:
    m.addGenConstrPow(dwq_exp[i,j], dwq[i,j], 1.852)

m.addConstrs((
    hl[i, j] == gp.quicksum(dw_arc_sizes[i, j, k]*(k**-4.87) for k in pipesize)*10700*arc_Distances[i, j]*1*(dwq_exp[i,j])/C for i, j in all_edges), "Headloss")
    
m.addConstrs((
    tdhp[i, j]*tdhp_bin[i,j] <= pl[i,j]*1000000 for i, j in all_edges), "Total Dynamic Head")
wwtp_capex = 1000000
dwtp_capex = 1000000

pipecost = {'0.05': 18, '0.06': 19, '0.08': 22, \
            '0.1': 25, '0.15': 62,'0.2': 171,\
            '0.25': 187, '0.3': 203, '0.35':230, \
            '0.4': 246, '0.45':262, '0.5':300, '0.6': 350,\
            '0.8': 500, '1.0': 550, '1.5': 650, '2.0': 800, '5.0': 1000}
        # pipe costs without excavation

obj1 = gp.quicksum(gp.quicksum(dw_arc_sizes[i, j, k]*pipecost[str(k)] for k in pipesize)*arc_Distances[i, j] for i, j in all_edges)
PC = 490 #cost of a pump station
obj2 = gp.quicksum(pl[i,j]*PC for i, j in all_edges)

COL_OM = 1000 #OM for pipes
PS_OM = 49#OM for pumps
Num_Connected = len(G_mst.nodes)
EX_Cost = 25

obj3 = COL_OM*Num_Connected + gp.quicksum(pl[i,j]*PS_OM for i, j in all_edges)
obj4 = gp.quicksum(EX_Cost*arc_Distances[i, j]*((elevation_ub[i]-e[i]+0.3048)+(elevation_ub[j]-e[j]+0.3048))*0.5 for i,j in half_edges)
obj5 = gp.quicksum(wwtp_capex*wwtp[i] + dwtp_capex*dwtp[i] for i in wwtp)
obj6 = gp.quicksum(wwq[i, j] for i, j in wwq)*1000000
obj = obj1 + obj2 + obj3 + obj4 +obj5

#note: the results for the wwq system are written backwards
#it goes (to, from) for the wastewater system
#meanwhile for dwq flow it goes (from, to)
#the reason I do this is because I found it easier to keep the edge sets the same
#across the two different optimization problems. Apologies for the weird notation

m.setObjective(obj, GRB.MINIMIZE)

m.optimize()
# print('The model is infeasible; computing IIS')
# m.computeIIS()
# if m.IISMinimal:
#     print('IIS is minimal\n')
# else:
#     print('IIS is not minimal\n')
# print('\nThe following constraint(s) cannot be satisfied:')
# for c in m.getConstrs():
#     if c.IISConstr:
#         print('%s' % c.constrName)

#check to make sure graph is connected


checkG = nx.Graph()
for i, j in dwq:
    if dwq[i, j].x >= 0:
        checkG.add_edge(i, j)

wwtp_chosen = []
dwtp_chosen = []
for i in wwtp:
    if wwtp[i].x == 1:
        wwtp_chosen.append(i)
    if dwtp[i].x == 1:
        dwtp_chosen.append(i)
try:
    len(wwtp_chosen) == 1 or len(dwtp_chosen) == 1
except:
    print('More than one was chosen')
    
    
try:
    nx.is_connected(checkG) == True
except:
    print("Pipes are not a connected network")
    
    
#first we need to get drinking water and wastewater demands of every building


#first we need to make sure the flow stuff works so lets just do a flow optimization with
#a simple constraint that will selelct the dwtp node
